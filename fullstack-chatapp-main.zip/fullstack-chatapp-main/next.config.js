module.exports = {
  reactStrictMode: true,
  env: {
    APP_ID: "1:9311945166:web:c1e3932fe27d228dcbeb9f",
    MESSAGING_SENDER_ID: "9311945166",
    STORAGE_BUCKET: "temp-chatapp.appspot.com",
    PROJECT_ID: "temp-chatapp",
    AUTH_DOMAIN: "temp-chatapp.firebaseapp.com",
    API_KEY: "AIzaSyDTKhoWxsh9ZtJBL1a8UwCV9YSa3ChB3eI",
  },
};
